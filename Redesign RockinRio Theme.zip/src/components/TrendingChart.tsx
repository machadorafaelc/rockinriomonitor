import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { name: '1 Sem', pearlJam: 85, iveteSangalo: 92, fooFighters: 78, theWho: 65 },
  { name: '2 Sem', pearlJam: 88, iveteSangalo: 89, fooFighters: 82, theWho: 68 },
  { name: '3 Sem', pearlJam: 92, iveteSangalo: 95, fooFighters: 85, theWho: 72 },
  { name: '4 Sem', pearlJam: 89, iveteSangalo: 88, fooFighters: 88, theWho: 75 },
  { name: 'Hoje', pearlJam: 94, iveteSangalo: 97, fooFighters: 91, theWho: 78 },
];

export function TrendingChart() {
  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <span className="text-primary">📈</span>
          Tendências dos Artistas
        </CardTitle>
        <CardDescription>
          Evolução do score social nas últimas 5 semanas
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.1)" />
              <XAxis 
                dataKey="name" 
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#a0a0a0', fontSize: 12 }}
              />
              <YAxis 
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#a0a0a0', fontSize: 12 }}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1a1a1a',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '8px',
                  color: '#ffffff',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)'
                }}
                labelStyle={{
                  color: '#ffffff',
                  fontWeight: '500'
                }}
                itemStyle={{
                  color: '#ffffff'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="pearlJam" 
                stroke="#ff4757" 
                strokeWidth={2}
                dot={{ fill: '#ff4757', strokeWidth: 2, r: 4 }}
                name="Pearl Jam"
              />
              <Line 
                type="monotone" 
                dataKey="iveteSangalo" 
                stroke="#2196f3" 
                strokeWidth={2}
                dot={{ fill: '#2196f3', strokeWidth: 2, r: 4 }}
                name="Ivete Sangalo"
              />
              <Line 
                type="monotone" 
                dataKey="fooFighters" 
                stroke="#4caf50" 
                strokeWidth={2}
                dot={{ fill: '#4caf50', strokeWidth: 2, r: 4 }}
                name="Foo Fighters"
              />
              <Line 
                type="monotone" 
                dataKey="theWho" 
                stroke="#ff9800" 
                strokeWidth={2}
                dot={{ fill: '#ff9800', strokeWidth: 2, r: 4 }}
                name="The Who"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}