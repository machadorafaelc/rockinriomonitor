import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';

const data = [
  { name: 'Positivo', value: 58, color: '#4caf50' },
  { name: 'Neutro', value: 32, color: '#ff9800' },
  { name: 'Negativo', value: 10, color: '#ff4757' },
];

export function SentimentChart() {
  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <span className="text-primary">💭</span>
          Análise de Sentimento
        </CardTitle>
        <CardDescription>
          Distribuição geral do sentimento sobre os artistas
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[250px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1a1a1a',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '8px',
                  color: '#ffffff',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)'
                }}
                labelStyle={{
                  color: '#ffffff',
                  fontWeight: '500'
                }}
                itemStyle={{
                  color: '#ffffff'
                }}
                formatter={(value) => [`${value}%`, 'Porcentagem']}
              />
              <Legend 
                wrapperStyle={{
                  color: '#a0a0a0',
                  fontSize: '14px'
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="grid grid-cols-3 gap-4 mt-4">
          {data.map((item) => (
            <div key={item.name} className="text-center">
              <div 
                className="w-3 h-3 rounded-full mx-auto mb-1" 
                style={{ backgroundColor: item.color }}
              />
              <p className="text-sm text-muted-foreground">{item.name}</p>
              <p className="font-semibold">{item.value}%</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}