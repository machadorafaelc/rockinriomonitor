import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Brain, TrendingUp, Target, AlertTriangle, Lightbulb } from "lucide-react";

const insights = [
  {
    id: 1,
    type: 'trend',
    title: 'Pearl Jam em Alta',
    description: 'Crescimento de 23% nas menções após anúncio de nova turnê mundial.',
    confidence: 92,
    priority: 'high',
    icon: TrendingUp,
    color: 'text-green-500'
  },
  {
    id: 2,
    type: 'opportunity',
    title: 'Colaboração Estratégica',
    description: 'Alok e Ivete Sangalo: alta compatibilidade de audiência para parceria.',
    confidence: 87,
    priority: 'medium',
    icon: Target,
    color: 'text-blue-500'
  },
  {
    id: 3,
    type: 'alert',
    title: 'Declínio The Who',
    description: 'Redução de 15% no engajamento. Recomenda-se campanha de reativação.',
    confidence: 78,
    priority: 'high',
    icon: AlertTriangle,
    color: 'text-yellow-500'
  },
  {
    id: 4,
    type: 'insight',
    title: 'Padrão Geracional',
    description: 'Artistas brasileiros têm 40% mais engajamento em horários noturnos.',
    confidence: 85,
    priority: 'low',
    icon: Lightbulb,
    color: 'text-purple-500'
  }
];

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case 'high': return 'bg-red-500/20 text-red-400 border-red-500/30';
    case 'medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
    case 'low': return 'bg-green-500/20 text-green-400 border-green-500/30';
    default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
  }
};

const getTypeEmoji = (type: string) => {
  switch (type) {
    case 'trend': return '🔥';
    case 'opportunity': return '🎯';
    case 'alert': return '⚠️';
    case 'insight': return '💡';
    default: return '🤖';
  }
};

export function AIInsightsPanel() {
  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5 text-primary" />
          Insights de IA
        </CardTitle>
        <CardDescription>
          Análises e recomendações geradas automaticamente
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {insights.map((insight) => {
            const IconComponent = insight.icon;
            return (
              <div 
                key={insight.id}
                className="p-4 rounded-lg border border-border bg-muted/30 hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{getTypeEmoji(insight.type)}</span>
                    <h4 className="font-semibold">{insight.title}</h4>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getPriorityColor(insight.priority)}>
                      {insight.priority}
                    </Badge>
                    <IconComponent className={`h-4 w-4 ${insight.color}`} />
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-3">
                  {insight.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">
                    Confiança: {insight.confidence}%
                  </span>
                  <div className="w-20 h-1 bg-muted rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary rounded-full transition-all duration-300"
                      style={{ width: `${insight.confidence}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}