import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { TrendingUp, TrendingDown, Music, Users, Heart } from "lucide-react";

interface ArtistCardProps {
  artist: {
    id: number;
    name: string;
    genre: string;
    country: string;
    socialScore: number;
    trendingScore: number;
    mentions: number;
    news: number;
    sentiment: 'positive' | 'negative' | 'neutral';
    trend: 'up' | 'down' | 'stable';
  };
}

export function ArtistCard({ artist }: ArtistCardProps) {
  const getTrendIcon = () => {
    if (artist.trend === 'up') return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (artist.trend === 'down') return <TrendingDown className="h-4 w-4 text-red-500" />;
    return null;
  };

  const getSentimentColor = () => {
    if (artist.sentiment === 'positive') return 'bg-green-500/20 text-green-400 border-green-500/30';
    if (artist.sentiment === 'negative') return 'bg-red-500/20 text-red-400 border-red-500/30';
    return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
  };

  return (
    <Card className="bg-card border-border hover:border-primary/50 transition-all duration-300 group">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Music className="h-5 w-5 text-primary" />
            {artist.name}
          </CardTitle>
          {getTrendIcon()}
        </div>
        <div className="flex gap-2">
          <Badge variant="outline" className="text-xs">
            {artist.genre}
          </Badge>
          <Badge variant="outline" className="text-xs">
            {artist.country}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Score Social</p>
            <p className="text-xl font-bold text-primary">{artist.socialScore}</p>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Trending</p>
            <p className="text-xl font-bold text-secondary">{artist.trendingScore}</p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-sm text-muted-foreground">Menções</p>
              <p className="font-semibold">{artist.mentions.toLocaleString()}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Heart className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-sm text-muted-foreground">Notícias</p>
              <p className="font-semibold">{artist.news}</p>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-border">
          <span className="text-sm text-muted-foreground">Sentimento</span>
          <Badge className={getSentimentColor()}>
            {artist.sentiment === 'positive' ? 'Positivo' : 
             artist.sentiment === 'negative' ? 'Negativo' : 'Neutro'}
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}