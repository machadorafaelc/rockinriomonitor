import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Newspaper, ExternalLink, Clock } from "lucide-react";

const news = [
  {
    id: 1,
    title: 'Pearl Jam anuncia turnê mundial com passagem pelo Brasil',
    source: 'Rolling Stone Brasil',
    time: '2 horas atrás',
    category: 'Turnê',
    sentiment: 'positive',
    artist: 'Pearl Jam'
  },
  {
    id: 2,
    title: 'Ivete Sangalo confirma participação no Rock in Rio 2024',
    source: 'G1 Música',
    time: '4 horas atrás',
    category: 'Festival',
    sentiment: 'positive',
    artist: 'Ivete Sangalo'
  },
  {
    id: 3,
    title: 'Foo Fighters lança documentário sobre nova fase da banda',
    source: 'Billboard Brasil',
    time: '6 horas atrás',
    category: 'Lançamento',
    sentiment: 'positive',
    artist: 'Foo Fighters'
  },
  {
    id: 4,
    title: 'Alok se torna o DJ brasileiro mais ouvido no Spotify',
    source: 'Tenho Mais Discos Que Amigos',
    time: '8 horas atrás',
    category: 'Conquista',
    sentiment: 'positive',
    artist: 'Alok'
  },
  {
    id: 5,
    title: 'Rolling Stones adia show devido a problemas técnicos',
    source: 'Folha de S.Paulo',
    time: '12 horas atrás',
    category: 'Cancelamento',
    sentiment: 'negative',
    artist: 'Rolling Stones'
  }
];

const getSentimentColor = (sentiment: string) => {
  switch (sentiment) {
    case 'positive': return 'bg-green-500/20 text-green-400 border-green-500/30';
    case 'negative': return 'bg-red-500/20 text-red-400 border-red-500/30';
    default: return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
  }
};

const getCategoryColor = (category: string) => {
  switch (category) {
    case 'Turnê': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
    case 'Festival': return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
    case 'Lançamento': return 'bg-green-500/20 text-green-400 border-green-500/30';
    case 'Conquista': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
    case 'Cancelamento': return 'bg-red-500/20 text-red-400 border-red-500/30';
    default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
  }
};

export function NewsPanel() {
  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Newspaper className="h-5 w-5 text-primary" />
          Notícias Recentes
        </CardTitle>
        <CardDescription>
          Últimas notícias sobre os artistas monitorados
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {news.map((item) => (
            <div 
              key={item.id}
              className="p-4 rounded-lg border border-border bg-muted/30 hover:bg-muted/50 transition-colors group cursor-pointer"
            >
              <div className="flex items-start justify-between mb-2">
                <h4 className="font-semibold text-sm leading-tight group-hover:text-primary transition-colors">
                  {item.title}
                </h4>
                <ExternalLink className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0 ml-2" />
              </div>
              
              <div className="flex items-center gap-2 mb-2">
                <Badge className={getCategoryColor(item.category)}>
                  {item.category}
                </Badge>
                <Badge className={getSentimentColor(item.sentiment)}>
                  {item.sentiment === 'positive' ? 'Positivo' : 
                   item.sentiment === 'negative' ? 'Negativo' : 'Neutro'}
                </Badge>
              </div>

              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>{item.source}</span>
                <div className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  <span>{item.time}</span>
                </div>
              </div>

              <div className="mt-2 pt-2 border-t border-border">
                <span className="text-xs font-medium text-primary">{item.artist}</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}