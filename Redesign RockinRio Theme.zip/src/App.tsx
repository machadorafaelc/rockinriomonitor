import { Header } from "./components/Header";
import { MetricCard } from "./components/MetricCard";
import { ArtistCard } from "./components/ArtistCard";
import { TrendingChart } from "./components/TrendingChart";
import { SentimentChart } from "./components/SentimentChart";
import { AIInsightsPanel } from "./components/AIInsightsPanel";
import { NewsPanel } from "./components/NewsPanel";
import { artistsData, totalMetrics } from "./data/artistsData";
import { Users, MessageSquare, Heart, Newspaper } from "lucide-react";
import exampleImage from 'figma:asset/fe6ffd80e162e935c2f1d62fc0c6573e0091058d.png';

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-6 py-8">
        {/* Logo Section */}
        <div className="flex justify-center mb-8">
          <div className="relative">
            <img 
              src={exampleImage} 
              alt="Rock in Rio Logo" 
              className="h-24 w-auto object-contain"
            />
          </div>
        </div>

        {/* Métricas Principais */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Artistas Monitorados"
            value={totalMetrics.totalArtists}
            description="12 artistas do Rock in Rio"
            icon={Users}
            className="border-primary/20"
          />
          <MetricCard
            title="Menções Sociais"
            value={totalMetrics.totalMentions.toLocaleString()}
            description="Total nas últimas 24h"
            icon={MessageSquare}
            trend={{ value: 12, label: "vs. ontem" }}
            className="border-secondary/20"
          />
          <MetricCard
            title="Sentimento Médio"
            value={`${totalMetrics.averageSentiment}%`}
            description="Positivo geral"
            icon={Heart}
            trend={{ value: 5, label: "vs. semana passada" }}
            className="border-green-500/20"
          />
          <MetricCard
            title="Notícias Coletadas"
            value={totalMetrics.totalNews}
            description="Últimas 24 horas"
            icon={Newspaper}
            trend={{ value: 8, label: "vs. ontem" }}
            className="border-yellow-500/20"
          />
        </div>

        {/* Gráficos e Insights */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <TrendingChart />
          </div>
          <div>
            <SentimentChart />
          </div>
        </div>

        {/* AI Insights e Notícias */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <AIInsightsPanel />
          <NewsPanel />
        </div>

        {/* Grid de Artistas */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-1 h-8 bg-primary rounded-full" />
            <h2 className="text-2xl font-bold">Artistas Monitorados</h2>
            <div className="flex-1 h-px bg-gradient-to-r from-primary/50 to-transparent" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {artistsData.map((artist) => (
              <ArtistCard key={artist.id} artist={artist} />
            ))}
          </div>
        </div>

        {/* Footer */}
        <footer className="border-t border-border pt-8 mt-12">
          <div className="text-center text-muted-foreground">
            <p className="mb-2">
              <span className="text-primary font-semibold">Rock in Rio</span> Artist Monitor Dashboard
            </p>
            <p className="text-sm">
              Monitoramento em tempo real para produtoras de eventos • 
              Desenvolvido com ❤️ para o mercado musical
            </p>
          </div>
        </footer>
      </main>
    </div>
  );
}