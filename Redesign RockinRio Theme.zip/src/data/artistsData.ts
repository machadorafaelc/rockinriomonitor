export const artistsData = [
  {
    id: 1,
    name: "Pearl Jam",
    genre: "Rock Alternativo",
    country: "EUA",
    socialScore: 94,
    trendingScore: 87,
    mentions: 45672,
    news: 23,
    sentiment: "positive" as const,
    trend: "up" as const
  },
  {
    id: 2,
    name: "Ivete Sangalo",
    genre: "Axé/Pop",
    country: "Brasil",
    socialScore: 97,
    trendingScore: 92,
    mentions: 52341,
    news: 18,
    sentiment: "positive" as const,
    trend: "up" as const
  },
  {
    id: 3,
    name: "Foo Fighters",
    genre: "Rock",
    country: "EUA",
    socialScore: 91,
    trendingScore: 85,
    mentions: 38945,
    news: 15,
    sentiment: "positive" as const,
    trend: "up" as const
  },
  {
    id: 4,
    name: "The Who",
    genre: "Rock Clássico",
    country: "Reino Unido",
    socialScore: 78,
    trendingScore: 71,
    mentions: 28765,
    news: 12,
    sentiment: "neutral" as const,
    trend: "down" as const
  },
  {
    id: 5,
    name: "Racionais MCs",
    genre: "Hip Hop",
    country: "Brasil",
    socialScore: 89,
    trendingScore: 83,
    mentions: 41236,
    news: 21,
    sentiment: "positive" as const,
    trend: "up" as const
  },
  {
    id: 6,
    name: "Green Day",
    genre: "Punk Rock",
    country: "EUA",
    socialScore: 86,
    trendingScore: 79,
    mentions: 35478,
    news: 14,
    sentiment: "positive" as const,
    trend: "stable" as const
  },
  {
    id: 7,
    name: "Rolling Stones",
    genre: "Rock Clássico",
    country: "Reino Unido",
    socialScore: 82,
    trendingScore: 76,
    mentions: 42891,
    news: 19,
    sentiment: "negative" as const,
    trend: "down" as const
  },
  {
    id: 8,
    name: "Roupa Nova",
    genre: "Pop Rock",
    country: "Brasil",
    socialScore: 75,
    trendingScore: 68,
    mentions: 22456,
    news: 8,
    sentiment: "neutral" as const,
    trend: "stable" as const
  },
  {
    id: 9,
    name: "Alok",
    genre: "EDM/House",
    country: "Brasil",
    socialScore: 95,
    trendingScore: 89,
    mentions: 67234,
    news: 26,
    sentiment: "positive" as const,
    trend: "up" as const
  },
  {
    id: 10,
    name: "Backstreet Boys",
    genre: "Pop",
    country: "EUA",
    socialScore: 81,
    trendingScore: 74,
    mentions: 31567,
    news: 11,
    sentiment: "positive" as const,
    trend: "stable" as const
  },
  {
    id: 11,
    name: "Beyoncé",
    genre: "R&B/Pop",
    country: "EUA",
    socialScore: 98,
    trendingScore: 95,
    mentions: 89432,
    news: 34,
    sentiment: "positive" as const,
    trend: "up" as const
  },
  {
    id: 12,
    name: "Lady Gaga",
    genre: "Pop/Dance",
    country: "EUA",
    socialScore: 93,
    trendingScore: 88,
    mentions: 56789,
    news: 22,
    sentiment: "positive" as const,
    trend: "up" as const
  }
];

export const totalMetrics = {
  totalArtists: artistsData.length,
  totalMentions: artistsData.reduce((sum, artist) => sum + artist.mentions, 0),
  averageSentiment: 73, // Calculated percentage of positive sentiment
  totalNews: artistsData.reduce((sum, artist) => sum + artist.news, 0)
};